import { describe, it, expect } from 'vitest';
import { fireEvent, render, screen } from '@testing-library/react';
import App from './App';

describe('HackiOS Web interface', () => {
  it('starts on the lock screen and unlocks to the home screen', () => {
    render(<App />);
    expect(screen.getByText('Swipe up to open')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: /unlock and go to home screen/i }));
    expect(screen.getByRole('button', { name: 'Open Settings' })).toBeInTheDocument();
  });
  it('opens Calculator and supports a basic calculation', () => {
    render(<App />);
    fireEvent.click(screen.getByRole('button', { name: /unlock and go to home screen/i }));
    fireEvent.click(screen.getByRole('button', { name: 'Open Calculator' }));
    fireEvent.click(screen.getByRole('button', { name: '7', exact: true }));
    fireEvent.click(screen.getByRole('button', { name: '+', exact: true }));
    fireEvent.click(screen.getByRole('button', { name: '5', exact: true }));
    fireEvent.click(screen.getByRole('button', { name: '=', exact: true }));
    expect(screen.getByText('12')).toBeInTheDocument();
  });
  it('returns from an app to the home screen', () => {
    render(<App />);
    fireEvent.click(screen.getByRole('button', { name: /unlock and go to home screen/i }));
    fireEvent.click(screen.getByRole('button', { name: 'Open Photos' }));
    fireEvent.click(screen.getByRole('button', { name: /return to home screen/i }));
    expect(screen.getByRole('button', { name: 'Open Settings' })).toBeInTheDocument();
  });
});