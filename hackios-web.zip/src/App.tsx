import { useEffect, useState } from 'react';
import { BatteryFull, Wifi, Signal, LockKeyhole, Flashlight, Camera, Settings, Images, Clock3, CalendarDays, Calculator, MapPin, CloudSun, Music2, ChevronLeft, Search, Moon, Sun, Plane, Bell, Smartphone, X, Check, Plus, Minus, Delete, RotateCcw, Maximize2 } from 'lucide-react';

type AppName = 'Settings' | 'Photos' | 'Clock' | 'Calendar' | 'Calculator' | 'Weather' | 'Maps' | 'Music';
const appInfo: {name: AppName; icon: typeof Settings; color: string; caption: string}[] = [
  {name:'Settings', icon:Settings, color:'linear-gradient(145deg,#aeb6c4,#667085)', caption:'System preferences'},
  {name:'Photos', icon:Images, color:'linear-gradient(145deg,#f9d36a,#f05d87 48%,#9565dc)', caption:'Your library'},
  {name:'Clock', icon:Clock3, color:'linear-gradient(145deg,#343943,#08090d)', caption:'Alarms and timers'},
  {name:'Calendar', icon:CalendarDays, color:'linear-gradient(145deg,#fff,#f1f2f5)', caption:'Your schedule'},
  {name:'Calculator', icon:Calculator, color:'linear-gradient(145deg,#555b67,#242833)', caption:'Quick calculations'},
  {name:'Weather', icon:CloudSun, color:'linear-gradient(145deg,#6bc8f3,#3973d9)', caption:'Local conditions'},
  {name:'Maps', icon:MapPin, color:'linear-gradient(145deg,#9ee5a6,#4a9f74)', caption:'Explore places'},
  {name:'Music', icon:Music2, color:'linear-gradient(145deg,#ff7595,#df275a)', caption:'Now playing'},
];
const weekdays = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
function dateLabel(d: Date) { return `${weekdays[d.getDay()]}, ${d.toLocaleDateString('en-US',{month:'long',day:'numeric'})}`; }
function StatusBar({dark=false}:{dark?:boolean}) { return <div className={`statusbar ${dark?'dark':''}`}><span>9:41</span><span className="status-icons"><Signal size={14} strokeWidth={2.6}/><Wifi size={15} strokeWidth={2.6}/><BatteryFull size={19} strokeWidth={2.2}/></span></div>; }

export default function App() {
  const [screen,setScreen] = useState<'lock'|'home'>('lock');
  const [opened,setOpened] = useState<AppName|null>(null);
  const [settingsTab,setSettingsTab] = useState('General');
  const [brightness,setBrightness] = useState(75);
  const [sound,setSound] = useState(60);
  const [calcDisplay,setCalcDisplay] = useState('0');
  const [calcStored,setCalcStored] = useState<number|null>(null);
  const [calcOp,setCalcOp] = useState<string|null>(null);
  const [calcFresh,setCalcFresh] = useState(true);
  const [now,setNow] = useState(new Date());
  const [full,setFull] = useState(false);
  const [toast,setToast] = useState('');
  useEffect(()=>{const id=window.setInterval(()=>setNow(new Date()),15000);return()=>clearInterval(id)},[]);
  useEffect(()=>{const handler=(e:KeyboardEvent)=>{if(e.key==='Escape'){if(opened)setOpened(null);else setScreen('home')} if(e.key==='Enter'&&screen==='lock')setScreen('home');};window.addEventListener('keydown',handler);return()=>window.removeEventListener('keydown',handler)},[opened,screen]);
  const notify=(s:string)=>{setToast(s);window.setTimeout(()=>setToast(''),1800)};
  const unlock=()=>{setScreen('home');setOpened(null)};
  const calc=(key:string)=>{
    if(/[0-9]/.test(key)&&key.length===1){setCalcDisplay(calcFresh||calcDisplay==='0'?key:calcDisplay+key);setCalcFresh(false);return}
    if(key==='AC'){setCalcDisplay('0');setCalcStored(null);setCalcOp(null);setCalcFresh(true);return}
    if(key==='±'){setCalcDisplay(String(-Number(calcDisplay)));return}
    if(key==='%'){setCalcDisplay(String(Number(calcDisplay)/100));return}
    if(key==='⌫'){setCalcDisplay(calcDisplay.length>1?calcDisplay.slice(0,-1):'0');return}
    if(key==='='){if(calcStored!==null&&calcOp){const a=calcStored,b=Number(calcDisplay);const v=calcOp==='+'?a+b:calcOp==='−'?a-b:calcOp==='×'?a*b:b===0?0:a/b;setCalcDisplay(String(Number(v.toPrecision(9))));setCalcStored(null);setCalcOp(null);setCalcFresh(true)}return}
    if(['+','−','×','÷'].includes(key)){setCalcStored(Number(calcDisplay));setCalcOp(key);setCalcFresh(true)}
  };
  const goHome=()=>{setOpened(null);setScreen('home')};
  const appButton=(name:AppName,Icon:typeof Settings,color:string,label=true)=><button className="app-button" key={name} onClick={()=>{setOpened(name);setScreen('home')}} aria-label={`Open ${name}`}><span className="app-icon" style={{background:color}}><Icon size={29} strokeWidth={1.8}/></span>{label&&<span className="app-label">{name}</span>}</button>;
  return <main className="site-shell">
    <header className="topbar"><a className="brand" href="#" onClick={e=>{e.preventDefault();goHome()}}><span className="brand-mark">H</span><span>HackiOS <b>Web</b></span></a><div className="top-actions"><span className="demo-pill"><span/> Browser demo</span><button className="icon-btn" aria-label="Toggle fullscreen" onClick={async()=>{try{if(!document.fullscreenElement){await document.documentElement.requestFullscreen();setFull(true)}else{await document.exitFullscreen();setFull(false)}}catch{notify('Fullscreen is not available in this browser')}}}><Maximize2 size={17}/></button><a className="github-link" href="https://github.com" target="_blank" rel="noreferrer">Project overview ↗</a></div></header>
    <section className="intro"><div className="eyebrow"><span className="eyebrow-dot"/> INTERFACE EXPERIMENT · 16.5-INSPIRED</div><h1>A familiar screen.<br/><span>A fresh perspective.</span></h1><p>Explore a lightweight, interactive mobile interface inspired by the look and feel of iOS 16.5 — right in your browser.</p><div className="intro-meta"><span><Smartphone size={15}/> Touch friendly</span><span><Check size={15}/> No firmware required</span><span><LockKeyhole size={14}/> Runs locally</span></div></section>
    <section className="demo-layout">
      <aside className="side-note"><span className="side-number">01 / EXPERIENCE</span><h2>Made to<br/>feel familiar.</h2><p>Swipe up or tap the arrow to unlock. Open an app, explore the interface, and return home using the bottom gesture bar.</p><div className="hint-card"><div className="hint-icon"><Plane size={17}/></div><div><b>Try it out</b><span>Open Settings or Calculator</span></div></div><div className="side-foot">DESIGNED FOR DESKTOP + MOBILE</div></aside>
      <div className="device-stage"><div className="device-glow"/><div className={`device ${screen==='lock'?'is-locked':''}`} style={{'--brightness':brightness/100} as React.CSSProperties}>
        <div className={`wallpaper ${screen==='lock'?'lock-wallpaper':'home-wallpaper'}`}></div><div className="wallpaper-grain"></div>
        <div className="device-island"></div>
        {screen==='lock'&&!opened?<div className="lock-screen" onTouchStart={e=>{(e.currentTarget as HTMLDivElement).dataset.startY=String(e.touches[0].clientY)}} onTouchEnd={e=>{const start=Number((e.currentTarget as HTMLDivElement).dataset.startY||0);if(start-e.changedTouches[0].clientY>45)unlock()}}>
          <StatusBar/><div className="lock-content"><div className="lock-date">{dateLabel(now)}</div><div className="lock-time">{now.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',hour12:false})}</div><div className="weather-chip"><CloudSun size={17}/><span>Mostly clear</span><b>72°</b></div>
            <div className="notification"><div className="notification-icon"><CalendarDays size={18}/></div><div className="notification-copy"><div><b>Calendar</b><time>now</time></div><strong>Something good is ahead.</strong><p>Your day is ready when you are.</p></div></div>
            <div className="notification"><div className="notification-icon photos-notice"><Images size={18}/></div><div className="notification-copy"><div><b>Photos</b><time>1m ago</time></div><strong>A little memory from today</strong><p>Your photo collection is waiting.</p></div></div>
          </div><div className="lock-shortcuts"><button aria-label="Flashlight" onClick={()=>notify('Flashlight demo control')}><Flashlight size={21}/></button><button aria-label="Camera" onClick={()=>{setOpened('Photos');setScreen('home')}}><Camera size={21}/></button></div><button className="unlock-hint" onClick={unlock}><span>Swipe up to open</span><span className="chevron-up">⌃</span></button><button className="home-indicator" aria-label="Unlock and go to home screen" onClick={unlock}></button>
        </div>:null}
        {screen==='home'&&!opened?<div className="home-screen"><StatusBar/><div className="home-widgets"><div className="widget weather-widget"><CloudSun size={24}/><div><b>72°</b><span>Mostly clear</span></div><small>Feels like 74°</small></div><div className="widget date-widget"><span>{weekdays[now.getDay()].toUpperCase()}</span><b>{now.getDate()}</b><small>{now.toLocaleDateString('en-US',{month:'long'})}</small></div></div><div className="app-grid">{appInfo.map(a=>appButton(a.name,a.icon,a.color))}</div><div className="page-dots"><span className="active"/><span/></div><div className="dock">{appInfo.slice(0,4).map(a=>appButton(a.name,a.icon,a.color,false))}</div><button className="home-indicator" aria-label="Return to lock screen" onClick={()=>{setScreen('lock');setOpened(null)}} title="Return to lock screen"></button></div>:null}
        {opened?<div className="app-screen"><StatusBar dark/><div className="app-topline"><button className="back-button" onClick={goHome}><ChevronLeft size={19}/> Home</button><span>{opened}</span><button className="close-app" aria-label="Close app" onClick={goHome}><X size={17}/></button></div>
          {opened==='Settings'?<div className="settings-content"><div className="settings-profile"><div className="profile-avatar"><Settings size={25}/></div><div><b>Demo Device</b><span>HackiOS Web · Interface preview</span></div><ChevronLeft className="profile-arrow" size={17}/></div><div className="settings-search"><Search size={16}/><span>Search</span></div><div className="settings-list">{[['Airplane Mode',Plane],['Notifications',Bell],['Focus',Moon],['Display & Brightness',Sun],['General',Settings],['Sounds & Haptics',Music2],['Privacy & Security',LockKeyhole]].map(([name,Icon])=><button key={name as string} className={`setting-row ${settingsTab===name?'selected':''}`} onClick={()=>{setSettingsTab(name as string);if(name==='Display & Brightness')notify('Use the brightness slider below')}}><span className="setting-icon"><Icon size={16}/></span><span>{name as string}</span><ChevronLeft className="row-arrow" size={16}/></button>)}</div><div className="adjust-card"><label>Display brightness <b>{brightness}%</b></label><input aria-label="Display brightness" type="range" min="20" max="100" value={brightness} onChange={e=>setBrightness(Number(e.target.value))}/><label>Ringer volume <b>{sound}%</b></label><input aria-label="Ringer volume" type="range" min="0" max="100" value={sound} onChange={e=>setSound(Number(e.target.value))}/></div></div>
          :opened==='Calculator'?<div className="calculator-content"><div className="calc-display" aria-live="polite">{calcDisplay}</div><div className="calc-keys">{[['AC','±','%','÷'],['7','8','9','×'],['4','5','6','−'],['1','2','3','+'],['⌫','0','.','=']].flat().map(k=><button key={k} className={`calc-key ${['÷','×','−','+','='].includes(k)?'operator':''} ${['AC','±','%','⌫'].includes(k)?'utility':''}`} onClick={()=>k==='.'?(!calcDisplay.includes('.')&&setCalcDisplay(calcDisplay+'.')):calc(k)}>{k==='⌫'?<Delete size={20}/>:k}</button>)}</div></div>
          :opened==='Photos'?<div className="generic-app photos-app"><div className="app-heading">Library <span>Today</span></div><div className="photo-grid"><div className="photo-tile photo-one"/><div className="photo-tile photo-two"/><div className="photo-tile photo-three"/><div className="photo-tile photo-four"/></div><p className="empty-note">A small demo collection, ready for your memories.</p></div>
          :opened==='Clock'?<div className="generic-app clock-app"><div className="clock-face"><span className="clock-hand hour-hand"/><span className="clock-hand minute-hand"/><span className="clock-pin"/></div><div className="digital-clock">{now.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',hour12:false})}</div><p>World Clock · Local demo time</p><button className="demo-action" onClick={()=>notify('Alarm demo — no alarm scheduled')}>＋ Add alarm</button></div>
          :opened==='Calendar'?<div className="generic-app calendar-app"><div className="calendar-title">{now.toLocaleDateString('en-US',{month:'long',year:'numeric'})}</div><div className="calendar-grid">{['S','M','T','W','T','F','S'].map((d,i)=><span key={d+i} className="weekday">{d}</span>)}{Array.from({length:31},(_,i)=><button key={i} className={i+1===now.getDate()?'today':''} onClick={()=>notify(`${now.toLocaleDateString('en-US',{month:'short'})} ${i+1} selected`)}>{i+1}</button>)}</div><p className="empty-note">No events scheduled. Enjoy the open space.</p></div>
          :opened==='Weather'?<div className="generic-app weather-app"><CloudSun size={60}/><div className="weather-temp">72°</div><p>Mostly clear</p><span>Demo weather · not a live forecast</span></div>
          :opened==='Maps'?<div className="generic-app maps-app"><div className="map-illustration"><span>⌖</span><div className="map-road road-one"/><div className="map-road road-two"/><div className="map-road road-three"/></div><h3>Explore nearby</h3><p>Map interaction is a visual demo; no location is collected.</p><button className="demo-action" onClick={()=>notify('Location is not enabled in this demo')}>Explore map</button></div>
          :<div className="generic-app music-app"><div className="album-art"><Music2 size={48}/></div><h3>Good things take time</h3><p>Demo track · HackiOS Sessions</p><div className="music-progress"><span/></div><div className="music-controls"><button onClick={()=>notify('Previous track')}>Ⅱ</button><button onClick={()=>notify('Playback is a demo')}>▶</button><button onClick={()=>notify('Next track')}>Ⅱ</button></div></div>}
          <button className="home-indicator app-indicator" aria-label="Return to home screen" onClick={goHome}></button>
        </div>:null}
      </div><div className="device-caption"><span><span className="caption-dot"/> LIVE PREVIEW</span><span>INTERACTIVE · RESPONSIVE</span></div></div>
      <aside className="right-note"><div className="step-card"><span>02</span><div><b>Unlock</b><p>Tap the home bar or swipe up.</p></div></div><div className="step-card"><span>03</span><div><b>Explore</b><p>Try Settings, Photos, or Calculator.</p></div></div><div className="step-card"><span>04</span><div><b>Return</b><p>Use the Home button or press Escape.</p></div></div><div className="disclaimer"><LockKeyhole size={15}/><p><b>Independent web project</b><br/>Not affiliated with Apple. This is a visual simulator, not genuine iOS or firmware emulation.</p></div></aside>
    </section>
    <footer className="footer"><span>HACKIOS WEB <i>·</i> COMMUNITY INTERFACE EXPERIMENT</span><span>BUILT FOR THE BROWSER <span className="footer-heart">✳</span></span></footer>
    {toast&&<div role="status" className="toast">{toast}</div>}
  </main>;
}