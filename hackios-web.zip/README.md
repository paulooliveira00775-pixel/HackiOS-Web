# HackiOS Web

A standalone, browser-based interface simulator inspired by the visual language of iOS 16.5. It recreates a lock screen, home screen, notification cards, app icons, and small interactive demo apps. It does **not** boot iOS, run Apple firmware, or emulate an operating-system kernel.

## Requirements

- Node.js 18 or newer (Node.js LTS recommended)
- npm (included with Node.js)

Get Node.js from <https://nodejs.org/>.

## Run locally

```bash
git clone https://github.com/YOUR-USERNAME/hackios-web.git
cd hackios-web
npm install
npm run dev
```

Open the local URL printed by Vite (usually `http://localhost:5173`). No firmware, virtual machine, QEMU, API key, or manual asset preparation is required.

### Helpful commands

```bash
npm run dev          # Development server
npm run dev:network  # Allow access from other devices on your local network
npm test             # Run automated interaction tests
npm run build        # Type-check and create the production build in dist/
npm run preview      # Preview the production build locally
```

To open the network version on a phone, connect both devices to the same Wi-Fi and use the network URL printed by Vite. Only use `dev:network` on a trusted network.

## Features

- Lock screen with live clock/date, wallpaper, notification cards, and unlock button/swipe-up gesture
- Home screen with app grid, widgets, dock, and status indicators
- Demo Settings, Photos, Clock, Calendar, Calculator, Weather, Maps, and Music apps
- Calculator operations and Settings brightness/volume controls
- Keyboard support: `Enter` unlocks the lock screen; `Escape` returns home or closes an app
- Responsive device frame, touch-friendly controls, and fullscreen button
- CSS-generated wallpapers and visual placeholders so the app does not depend on image downloads

Weather, notifications, Maps, camera, music playback, and alarms are illustrative demo content, not connected services. The displayed weather is not a live forecast. This project is independent and is not affiliated with Apple.

## Deploy to GitHub Pages

1. Push this repository to GitHub.
2. Open **Settings → Pages** in the repository.
3. Under **Build and deployment**, select **GitHub Actions**.
4. Add `.github/workflows/deploy.yml` (provided in this repository).
5. Push to the default branch. The Actions workflow builds and publishes `dist/`; the deployed URL appears in the workflow summary and Pages settings.

For an alternative, import the repository into Vercel or Netlify and use the default Vite build command `npm run build` and output directory `dist`.

## Troubleshooting

- **`node` or `npm` not found:** install Node.js LTS from <https://nodejs.org/>, close and reopen the terminal, and retry `node -v` and `npm -v`.
- **Dependencies appear missing:** run `npm install` from the project folder.
- **Port already in use:** follow the alternate local URL Vite prints, or stop the other process using that port.
- **Build errors:** check that your Node.js version is 18+, then run `npm install` and `npm run build`.
- **Tests:** run `npm test`. Tests run in jsdom and do not require a real mobile device.

## Project structure

```text
hackios-web/
├── .github/workflows/deploy.yml
├── scripts/check-env.mjs
├── src/
│   ├── App.tsx
│   ├── App.test.tsx
│   ├── main.tsx
│   ├── styles.css
│   └── test-setup.ts
├── index.html
├── package.json
├── tsconfig*.json
└── vite.config.ts
```

## License

MIT. See `LICENSE`.
