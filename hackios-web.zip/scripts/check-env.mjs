import { execSync } from 'node:child_process';
const major = Number(process.versions.node.split('.')[0]);
if (major < 18) {
  console.error(`HackiOS Web needs Node.js 18 or newer. Current version: ${process.version}\nInstall a current LTS version from https://nodejs.org/ and try again.`);
  process.exit(1);
}
try { execSync('npm --version', { stdio: 'ignore' }); }
catch {
  console.error('npm was not found. Install Node.js from https://nodejs.org/ (npm is included), then reopen your terminal.');
  process.exit(1);
}
console.log(`Environment OK — Node.js ${process.version}`);
